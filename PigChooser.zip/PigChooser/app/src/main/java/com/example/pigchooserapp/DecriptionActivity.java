package com.example.pigchooserapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

public class DecriptionActivity extends AppCompatActivity {


    TextView name,description;
    ImageView image,berkshire, duroc,tamworth,hampshire,mangalica,largewhite,mukota,potbelly;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decription);

        berkshire = findViewById(R.id.image_berkshire);
        duroc = findViewById(R.id.imageView_duroc);
        tamworth = findViewById(R.id.imageView_tamworth);
        hampshire = findViewById(R.id.imageView_hampshire);
        mangalica = findViewById(R.id.imageView_mangalica);
        largewhite = findViewById(R.id.imageView_largewhite);
        mukota = findViewById(R.id.imageView_mukota);
        potbelly = findViewById(R.id.imageView_potbelly);
        image = findViewById(R.id.imageView_image);
        name = findViewById(R.id.textView);
        description = findViewById(R.id.textView_description);



        Intent intent = getIntent();
        name.setText(intent.getStringExtra("name"));
        image.setImageResource(intent.getIntExtra("image",0));
    }

        public String loadJSONFromAsset() {
            String json = null;
            try {

                InputStream is = getAssets().open("pigs.json");

                int size = is.available();

                byte[] buffer = new byte[size];

                is.read(buffer);

                is.close();

                json = new String(buffer, "UTF-8");


            } catch (IOException ex) {
                ex.printStackTrace();
                return null;
            }
            return json;




    }
}
