package com.example.pigchooserapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.EventLogTags;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Button button;
    Random r;
    ImageView image1;
    GridView gridview;
    String[] pigNames = new String[]{"Berkshire", "Duroc", "TamWorth", "Hampshire", "Largewjite", "mangalica", "Mukota", "Potbelly"};
    int[] pigImages = new int[]{R.drawable.berkshire_desc, R.drawable.duroc_desc, R.drawable.tamworth_desc, R.drawable.hampshire_desc, R.drawable.largewhite_desc, R.drawable.mangalica_desc, R.drawable.mukota_desc, R.drawable.potbelly_list};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gridview = findViewById(R.id.gridview);
        button = findViewById(R.id.button_choose);
        image1 = findViewById(R.id.imageView_1);

        CustomAdapter customadapter = new CustomAdapter();
        gridview.setAdapter(customadapter);

        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Intent intent = new Intent(getApplicationContext(), DecriptionActivity.class);
                intent.putExtra("name", pigNames[i]);
                intent.putExtra("image", pigImages[i]);
                startActivity(intent);

            }
        });


        button  = findViewById(R.id.button_choose);
        image1 = findViewById(R.id.imageView_1);
        r = new Random();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //display random images
                image1.setImageResource(pigImages[r.nextInt(pigImages.length)]);
            }
        });
        r = new Random();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //display random images
                image1.setImageResource(pigImages[r.nextInt(pigImages.length)]);
            }
        });

        try {
            for (int count = 5; count >= 0; count--) {
                Thread.sleep(1000);
                publishProgress("" + count);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void publishProgress(String s) {
        System.out.println("Doing complex calculations showing in ...");
    }

    private class CustomAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return pigImages.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = getLayoutInflater().inflate(R.layout.activity_decription, null);

            TextView name = view.findViewById(R.id.textView_description);
            ImageView image = view.findViewById(R.id.imageView_image);

            name.setText(pigNames[position]);
            image.setImageResource(pigImages[position]);
            return view;

        }
    }
}
