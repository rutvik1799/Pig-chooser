package com.example.pigchooserapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class RandomChooser extends AppCompatActivity {
    Button button;
    ImageView image1;
    Random r;
    String[] pigNames = {"Berkshire","Duroc","TamWorth","Hampshire","Largewjite","mangalica","Mukota","Potbelly" };
    int[] pigImages = {R.drawable.berkshire_desc,R.drawable.duroc_desc,R.drawable.tamworth_desc,R.drawable.hampshire_desc,R.drawable.largewhite_desc,R.drawable.mangalica_desc,R.drawable.mukota_desc,R.drawable.potbelly_list};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random_chooser);


        button  = findViewById(R.id.button_choose);
        image1 = findViewById(R.id.imageView_1);
        r = new Random();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //display random images
                image1.setImageResource(pigImages[r.nextInt(pigImages.length)]);
            }
        });


    }
}
